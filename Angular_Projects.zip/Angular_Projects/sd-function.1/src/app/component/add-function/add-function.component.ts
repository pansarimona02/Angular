import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-function',
  templateUrl: './add-function.component.html',
  styleUrls: ['./add-function.component.css']
})
export class AddFunctionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
