import { Component, OnInit } from '@angular/core';
import { Functions, Tags, ReturnTypes, ComplexType, Parameters } from 'src/app/model/function';
import { Router } from '@angular/router';
import { FunctionService } from 'src/app/service/function.service';
import { BlockingProxy } from 'blocking-proxy';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-function',
  templateUrl: './function.component.html',
  styleUrls: ['./function.component.css']
})
// export let browserRefresh = false;
export class FunctionComponent implements OnInit {
  func: Functions;
  parameters: Parameters[];

  constructor(private http: HttpClient, private router: Router, private functionService: FunctionService) {
    this.func =  Functions.createBlank();
    this.parameters = [];
  }
  display = 'none';
  showModal = 1;

  functions: Functions[];
  tags: Tags[];
  returns: ReturnTypes[];

 //  datatypes: ReturnTypes[];
  // call services inside this
  ngOnInit() {
    this.functionService.refreshNeed.subscribe(() => {
      this.getall();
    });
    this.getall();
    this.functionService.getTags().subscribe(data => {
      this.tags = data;

    });
    this.functionService.getReturnType().subscribe(data => {
      this.returns = data;

    });

  }
  private getall() {
  this.functionService.getAll().subscribe(data => {
    this.functions = data;
  });
}
  onSelect() {
    this.functionService.getTags().subscribe(data => {
      this.tags = data;
      console.log(data);
    });
  }

  createUser(event): void {
    console.log(this.func);
    this.functionService.createFunction(this.func)
      .subscribe(data => {
        console.log(data);
      });
    for (const parameter of this.parameters) {
    this.functionService.createLabels(parameter)
  .subscribe(data => {

  });
    this.func =  Functions.createBlank();
}
    this.showModal = 1;
    this.display = 'none';
  }




  addLabelPressed(): void {
    if (!this.parameters) {
      this.parameters = [{id: null, label: null, returnType: null, subType: null, functionId: null, functionName: this.func.functionName }];
    } else {
      this.parameters.push({id: null, label: null, returnType: null, subType: null, functionId: null,
         functionName: this.func.functionName  });
    }

  }
  removeLabelAtIndex(i) {
    this.parameters.splice(i, 1);
  }















  deleteFunction(func) {

    this.functionService.deleteFunction(func)
    .subscribe(data => {
      const index =  this.functions.indexOf(func);
      this.functions.splice(index, 1);
      // alert('User Deleted successfully.');
    });
  }

  next() {
    this.showModal = 2;
    this.display = 'block';
  }
  prev() {
    this.showModal = 1;
    this.display = 'block';
  }
  addFunction() {
    this.display = 'block';
  }

  closeFunction() {
    this.display = 'none';
  }

}
