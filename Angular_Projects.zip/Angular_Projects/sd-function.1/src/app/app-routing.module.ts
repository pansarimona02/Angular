import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FunctionComponent } from './component/function/function.component';
import { AddFunctionComponent } from './component/add-function/add-function.component';

const routes: Routes = [
  { path: '', pathMatch: 'full',  redirectTo: 'function' },
  { path: 'function', component: FunctionComponent},
  { path: 'addfunction', component: AddFunctionComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
