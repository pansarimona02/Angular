import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { FunctionService } from './service/function.service';
import { FunctionComponent } from './component/function/function.component';
import { AddFunctionComponent } from './component/add-function/add-function.component';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    FunctionComponent,
    AddFunctionComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
    // RouterModule.forRoot([
    //   {
    //     path: '',
    //     redirectTo: '/function',
    //     pathMatch: 'full'
    //   },
    //   {
    //     path: 'function',
    //     component: FunctionComponent
    //   }
    // ])
  ],
  providers: [FunctionService],
  bootstrap: [AppComponent]
})
export class AppModule { }
