import { Injectable } from '@angular/core';

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Functions, Parameters } from '../model/function';
import { Observable, Subject } from 'rxjs';
import { tap } from 'rxjs/operators';


const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class FunctionService {

  constructor(private http: HttpClient) { }

  private refreshNeeded = new Subject<void>();
  private Url = 'http://localhost:8080/rest/functions';

  get refreshNeed() {
    return this.refreshNeeded;
  }

  public getAll(): Observable<any> {
    return this.http.get(this.Url + '/all');
  }
  // Get Tags
  public getTags(): Observable<any> {
    return this.http.get(this.Url + '/tags/all');
  }

  public getReturnType(): Observable<any> {
    return this.http.get(this.Url + '/return/all');
  }

  public deleteFunction(func) {
    return this.http.delete(this.Url + '/' + func.idfunction);
  }

  public createFunction(func: Functions) {

    return this.http.post<Functions>(this.Url + '/load', JSON.stringify(func), httpOptions).pipe(
      tap(() => {
        this.refreshNeeded.next();
      })
    );

  }
  public createLabels(param: Parameters) {

    return this.http.post<Functions>(this.Url + '/param/load', JSON.stringify(param), httpOptions);
  }


}

