
export class Functions {
    id: number;
    functionName: string;
    label: string;
    tags: string;
    description: string;
    returnType: number;
    subType: number;


    constructor(
                functionName: string,
                label: string,
                tags: string,
                description: string,
                returnType: number,
                subtype: number) {
        this.functionName = functionName;
        this.label = label;
        this.tags = tags;
        this.description = description;
        this.returnType = returnType;
        this.subType = subtype;
    }
    // public static functionfromJSON(obj: any): Functions {
    //     return new Functions(obj.id, obj.functionName, obj.label, obj.tags, obj.description, obj.returnType);

    // }

    public static createBlank() {
        return new Functions( null, null, null, null, null, null);
    }

}
export class Tags {
    id: number;
    tag: string;
}

export class ReturnTypes {
    id: number;
    returnTypeName: string;
    subtypeflag: string;
    configFlag: string;
}
export class ComplexType {
    id: number;
    returnTypeName: string;
}
export class Parameters {
    id: number;
    label: string;
    returnType: number;
    subType: number;
    functionId: number;
    functionName: string;


    constructor(label: string,
                returnType: number,
                subtype: number,
                functionId: number,
                functionName: string) {
        this.label = label;
        this.returnType = returnType;
        this.subType = subtype;
        this.functionId = functionId;
        this.functionName = functionName;

}
    public static createBlankParam() {
        return new Parameters(null, null, null, -1, null);
    }
}
// export class Function implements Function {

// }
