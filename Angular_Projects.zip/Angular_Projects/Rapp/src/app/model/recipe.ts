// import { constructDependencies } from '@angular/core/src/di/reflective_provider';
// import { strictEqual } from 'assert';
import { stringify } from '@angular/core/src/render3/util';

export interface Ingredient {
    ingredient: string;
    measure: string;
}

export interface Instruction {
    instruction: string;
    photo: string;
}

export class Recipe {
    public id: number;
    public title: string;
    public description: string;
    public feedsThisMany: number;
    public preparationTime: number;
    public ingredients: Ingredient[];
    public instructions: Instruction[];
    public coverPhoto: string;
    public keywords: string[];

    constructor(id: number, t: string, d: string,
                pt: number, feeds: number, ingr: Ingredient[],
                inst: Instruction[], cp: string,
                keywords: string[]) {
        this.id = id;
        this.title = t;
        this.description = d;
        this.ingredients = ingr;
        this.instructions = inst;
        this.coverPhoto = cp;
        this.preparationTime = pt;
        this.feedsThisMany = feeds;
        this.keywords = keywords;

    }
    /*We can write construction in following way either
    constructor(public title: stringify,
                public description: stringi,
                public ingredients: Ingredient[],
                public instruction: Instruction[],
                public coverPhoto: string,
                ){
                }*/
                public static recipefromJSON(obj: any): Recipe {
                    return new Recipe(obj.id, obj.title,
                       obj.description, obj.preparationTime,
                       obj.feedsThisMany, obj.ingredients, obj.instructions, obj.coverPhoto, obj.keywords);

                }

    public static createBlank() {
        return new Recipe(-1, '', '', 1, 1, [], [], null, null);
     }




}

