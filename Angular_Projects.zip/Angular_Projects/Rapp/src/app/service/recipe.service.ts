import { Injectable } from '@angular/core';
import { Recipe } from '../model/recipe';
import { promise } from 'protractor';
import { resolveCname } from 'dns';
import { Http } from '@angular/http';

const RECIPE_SERVER = 'http://localhost:8080';
@Injectable({
  providedIn: 'root'
})
export class RecipeService {

  constructor(private http: Http) {
  }

  getAllRecipe(): Promise<Recipe[]> {
    return this.http.get(RECIPE_SERVER + '/v1/recipes.json')
      .toPromise()
      .then(response => response.json().data as Recipe[])
      .catch(this.handleError);
  }
  // function to get these recipes
  // getAllRecipe(): Promise<Recipe[]> {
  //   return new Promise((resolve, reject) => {
  //     setTimeout(() => {
  //       resolve(this.recipes);
  //     }, 1000);
  //   });

  // }
  getRecipeById(recipeId: number): Promise<Recipe> {
    return this.http
      .get(RECIPE_SERVER + `/v1/recipes/${recipeId}.json`)
      .toPromise()
      .then(response => response.json().data as Recipe)
      .catch(this.handleError);


  }
  // getRecipeById(recipeId: number): Promise<Recipe> {
  //   return new Promise((resolve, reject) => {
  //     setTimeout(() => {
  //       for (const recipe of this.recipes) {
  //         if (recipe.id === recipeId) {
  //           resolve(recipe);
  //           return;
  //         }
  //       }

  //       reject(Error('No Recipe Exists with that Id'));
  //     }, 1000);
  //   });
  // }

  addNewRecipe(recipe: Recipe): Promise<Recipe> {
    return this.http.put(RECIPE_SERVER + '/v1/recipes.json', recipe)
      .toPromise()
      .then(response => response.json().data as Recipe)
      .catch(this.handleError);
    console.log(recipe);
  }
  private handleError(error: any): Promise<any> {
    console.error(' ERROR OCCURED TAKING TO SERVER ' + error );
    return Promise.reject(error.message || error);
  }
}
