import { Component, OnInit } from '@angular/core';
import { Recipe } from '../../model/recipe';
import { Router } from '@angular/router';
import { RecipeService } from 'src/app/service/recipe.service';

@Component({
  selector: 'app-recipe-list',
  templateUrl: './recipe-list.component.html',
  styleUrls: ['./recipe-list.component.css']
})
export class RecipeListComponent implements OnInit {

  recipes: Recipe[];
  recipeLoaded: boolean;
  loadError: boolean;
  errorText: string;
  // recipeInProgress: Recipe;

  constructor(private router: Router,
              private recipeService: RecipeService) { // dependency injection
    // this.recipeInProgress = Recipe.createBlank();
    this.loadError = false;

  }
  ngOnInit() {
    // recipe service to get the recipe
    this.recipeService.getAllRecipe()
    .then((recipes) => {
      this.recipes = recipes;
      this.recipeLoaded = true;
    })
    .catch((err) => {
      this.loadError = true;
      const body = JSON.parse(err._body);
      this.errorText = body.message;
    });
  }

  // addrecipeclicked
  public zoomInRecipe(recipe) {
    console.log('the user clicked on recipe: ');
    console.log(JSON.stringify(recipe, null, 2));
  }
  userClickedOnRecipe(recipeid): void {
    this.router.navigateByUrl('/recipes/' + recipeid);
  }
  addNewRecipe() {
    this.router.navigateByUrl('/addNewRecipe');
  }
}
