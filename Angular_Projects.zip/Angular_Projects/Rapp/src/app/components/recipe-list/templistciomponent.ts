
import { Component, OnInit } from '@angular/core';
import { Recipe } from 'src/app/model/recipe';
import { ParamMap, ActivatedRoute, Router } from '@angular/router';
import { switchMap } from 'rxjs/operators';
import { RecipeService } from 'src/app/service/recipe.service';

@Component({
  selector: 'app-recipe-details',
  templateUrl: './recipe-details.component.html',
  styleUrls: ['./recipe-details.component.css']
})
export class RecipeDetailsComponent implements OnInit {

  recipes: Recipe[];
  recipe: Recipe;
  constructor(private route: ActivatedRoute, private router: Router, private recipeService: RecipeService) {
  }

  ngOnInit(): void {
    // recipe service to get the recipe
    this.recipeService.getAllRecipe()
      .then((recipes) => this.recipes = recipes);

    this.route.paramMap.subscribe((params: ParamMap) => {
      this.recipe = this.findRecipeById(parseInt(params.get('recipe_id'), 10));
      /*recipe_id  is id thet is pasd inpath in module.ts,  parameter, 10-base 10*/
    });

  }
  findRecipeById(id: number): Recipe {
    for (const recipe of this.recipes) {
      if (recipe.id === id) {
        return recipe;
      }

    }
    return null;
  }
  goBackButtonPressed() {
    this.router.navigateByUrl('/recipes');
  }

}
