import { Component, OnInit } from '@angular/core';
import { Recipe } from 'src/app/model/recipe';
import { ParamMap, ActivatedRoute, Router } from '@angular/router';
import { switchMap } from 'rxjs/operators';
import { RecipeService } from 'src/app/service/recipe.service';

@Component({
  selector: 'app-recipe-details',
  templateUrl: './recipe-details.component.html',
  styleUrls: ['./recipe-details.component.css']
})
export class RecipeDetailsComponent implements OnInit {


  recipe: Recipe;
  loadError: boolean;
  errorText: string;

  constructor(private route: ActivatedRoute,
              private router: Router,
              private recipeService: RecipeService) {
                this.loadError = false;
  }

  ngOnInit(): void {
    this.route.paramMap.subscribe((params: ParamMap) => {
      const recipeId = parseInt(params.get('recipe_id'), 10);
      this.recipeService.getRecipeById(recipeId)
      .then((recipe) => this.recipe = recipe)
      .catch((err) => {
        this.loadError = true;
        const body = JSON.parse(err._body);
        this.errorText = body.message;
      });
      /*recipe_id  is id thet is pasd inpath in module.ts,  parameter, 10-base 10*/
    });
  }

  goBackButtonPressed() {
    this.router.navigateByUrl('/recipes');
  }

}



