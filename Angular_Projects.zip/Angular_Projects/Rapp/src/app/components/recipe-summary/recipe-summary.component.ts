import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Recipe } from 'src/app/model/recipe';
/*import { EventEmitter } from 'events';*/

@Component({
  selector: 'app-recipe-summary',
  templateUrl: './recipe-summary.component.html',
  styleUrls: ['./recipe-summary.component.css']
})
export class RecipeSummaryComponent {

  @Input()
  recipe: Recipe;

 @Output()
  userClick: EventEmitter<number> = new EventEmitter<number>();
  zoomIn: EventEmitter<Recipe> = new EventEmitter();
  constructor() { }

  public zoomClicked() {
    this.zoomIn.emit(this.recipe);
  }

  public userClicked() {
    this.userClick.emit(this.recipe.id); /*emit send data( i.e recipe.id) to parent componennt*/
  }
}
