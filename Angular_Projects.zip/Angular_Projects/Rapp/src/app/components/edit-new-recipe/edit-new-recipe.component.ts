import { Component, OnInit } from '@angular/core';
import { Recipe } from 'src/app/model/recipe';
import { RecipeService } from 'src/app/service/recipe.service';
import { Router } from '@angular/router';
import { AbstractControl, ValidatorFn, FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-edit-new-recipe',
  templateUrl: './edit-new-recipe.component.html',
  styleUrls: ['./edit-new-recipe.component.css']
})
export class EditNewRecipeComponent implements OnInit {


  recipeInProgress: Recipe;
  constructor(private recipeService: RecipeService, private router: Router) {
    this.recipeInProgress = Recipe.createBlank();
   // this.disableAddRecipeButton = true;
  }

  ngOnInit() {
  }
  // for add recipe button
  addRecipeButtonPressed(): void {
    this.recipeService.addNewRecipe(this.recipeInProgress)
      .then((recipe) => {
        this.router.navigate(['recipes', recipe.id]);
      });
  }
  // public addRecipeClicked() {
  //   console.log(JSON.stringify(this.recipeInProgress, null, 2));
  //   this.recipes.push(this.recipeInProgress);
  //   this.recipeInProgress = Recipe.createBlank();
  // }
  addIngredientPressed(): void {
    if (!this.recipeInProgress.ingredients) {
      this.recipeInProgress.ingredients = [{ ingredient: null, measure: null }];
    } else {
      this.recipeInProgress.ingredients.push({ ingredient: null, measure: null });
    }

  }
  addInstructionPressed(): void {
    if (!this.recipeInProgress.instructions) {
      this.recipeInProgress.instructions = [{ instruction: null, photo: null }];
    } else {
      this.recipeInProgress.instructions.push({ instruction: null, photo: null });
    }

  }
  removeIngredientAtIndex(i): void {
    this.recipeInProgress.ingredients.splice(i, 1);
  }
  removeinstructionAtIndex(i) {
    this.recipeInProgress.instructions.splice(i, 1);
  }

  /*validateForm(event): void {
    this.disableAddRecipeButton = true;
    if (!this.recipeInProgress.title || this.recipeInProgress.title.length < 1) {
      return;
    }
    if (!this.recipeInProgress.description || this.recipeInProgress.description.length < 1) {
      return;
    }
    const feeds = parseInt('' + this.recipeInProgress.feedsThisMany, 10);
    const preptime = parseInt('' + this.recipeInProgress.preparationTime, 10);
    if (isNaN(feeds) || feeds < 1 || feeds > 1000) {
      return;
    }
    if (isNaN(preptime) || preptime < 1) {
      return;
    }
    for (const instr of this.recipeInProgress.instruction) {
      if (!instr.instruction || instr.instruction.length < 1) {
        return;
      }
      // if (!instr.photo || instr.photo.length < 1) {
      //   return;
      // }

    }
    for (const ingred of this.recipeInProgress.ingredients) {
      if (!ingred.ingredient || ingred.ingredient.length < 1) {
        return;
      }
      if (!ingred.measure || ingred.measure.length < 1) {
        return;
      }

    }
    this.disableAddRecipeButton = false;
  }*/
}
