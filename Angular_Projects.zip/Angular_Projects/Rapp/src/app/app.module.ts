import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {RouterModule } from '@angular/router';

import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { RecipeListComponent } from './components/recipe-list/recipe-list.component';
import { RecipeSummaryComponent } from './components/recipe-summary/recipe-summary.component';
import { RecipeDetailsComponent } from './components/recipe-details/recipe-details.component';
import { EditNewRecipeComponent } from './components/edit-new-recipe/edit-new-recipe.component';
import { RecipeService } from './service/recipe.service';
import { HttpModule } from '@angular/http';


@NgModule({
  declarations: [
    AppComponent,
    RecipeListComponent,
    RecipeSummaryComponent,
    RecipeDetailsComponent,
    EditNewRecipeComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    RouterModule.forRoot([
      {
        path: '',
        redirectTo: '/recipes',
        pathMatch: 'full'
       },
      {
        path: 'recipes',
        component: RecipeListComponent
      },
      {
        path: 'addNewRecipe',
        component: EditNewRecipeComponent
      },
      {
        path: 'recipes/:recipe_id',
        component: RecipeDetailsComponent
      }
    ])
  ],
  providers: [ RecipeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
