package com.sdfunction.db.demo.models;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;



@Entity
@Table(name="functions")
public class Functions {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idfunction; 
	private String functionName;
	private String label;
	private String Tags;
	private String description;
	private Integer datatypeId;
	private Integer subtypeId;
	@OneToMany(targetEntity=Parameters.class, mappedBy="functionId",cascade = CascadeType.ALL, fetch=FetchType.EAGER)
	private Set<Parameters> parameters;

   
	public Set<Parameters> getParameters() {
		return parameters;
	}
	public void setParameters(Set<Parameters> parameters) {
		this.parameters = parameters;
	}
	public Integer getSubType() {
		return subtypeId;
	}
	public void setSubType(Integer subType) {
		this.subtypeId = subType;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getIdfunction() {
		return idfunction;
	}
	public void setIdfunction(Integer idfunction) {
		this.idfunction = idfunction;
	}
	public String getFunctionName() {
		return functionName;
	}
	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public String getTags() {
		return Tags;
	}
	public void setTags(String tags) {
		Tags = tags;
	}
	public Integer getReturnType() {
		return datatypeId;
	}
	public void setReturnType(Integer returnType) {
		this.datatypeId = returnType;
	}

}
