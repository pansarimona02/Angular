package com.sdfunction.db.demo.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="parameters")
public class Parameters {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer idparameters; 
	private String functionName;
	private String label;
	private Integer functionId;
	private Integer datatypeId;
	private Integer subtypeId;
	
	public String getFunctionName() {
		return functionName;
	}
	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}
	


	public Integer getSubType() {
		return subtypeId;
	}
	public void setSubType(Integer subType) {
		this.subtypeId = subType;
	}
	
	public Integer getIdparameters() {
		return idparameters;
	}
	public void setIdparameters(Integer idparameters) {
		this.idparameters = idparameters;
	}
	
	
	

	public Integer getFunctionId() {
		return functionId;
	}
	public void setFunctionId(Integer functionId) {
		this.functionId = functionId;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public Integer getReturnType() {
		return datatypeId;
	}
	public void setReturnType(Integer returnType) {
		this.datatypeId = returnType;
	}

}
