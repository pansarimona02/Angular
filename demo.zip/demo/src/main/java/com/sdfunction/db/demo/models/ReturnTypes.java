package com.sdfunction.db.demo.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="returntype")
public class ReturnTypes {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer idReturn; 
	private String returnTypeName;
	private boolean subtypeFlg;
	private boolean configFlg;
	public boolean isSubtypeFlg() {
		return subtypeFlg;
	}
	public void setSubtypeFlg(boolean subtypeFlg) {
		this.subtypeFlg = subtypeFlg;
	}
	public boolean isConfigFlg() {
		return configFlg;
	}
	public void setConfigFlg(boolean configFlg) {
		this.configFlg = configFlg;
	}
	public Integer getIdReturn() {
		return idReturn;
	}
//	public void setIdReturn(Integer idReturn) {
//		this.idReturn = idReturn;
//	}
	public String getReturnTypeName() {
		return returnTypeName;
	}
	public void setReturnTypeName(String returnTypeName) {
		this.returnTypeName = returnTypeName;
	}

	

}
