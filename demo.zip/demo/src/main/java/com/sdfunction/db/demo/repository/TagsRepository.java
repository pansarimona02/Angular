package com.sdfunction.db.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sdfunction.db.demo.models.Tags;

public interface TagsRepository extends JpaRepository<Tags, Integer> {

}
