package com.sdfunction.db.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sdfunction.db.demo.models.ReturnTypes;


public interface ReturnTypeRepository extends JpaRepository<ReturnTypes, Integer> {

}
