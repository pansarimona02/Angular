package com.sdfunction.db.demo.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="tags")
public class Tags {
	public Integer getIdtags() {
		return idtags;
	}
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer idtags; 
	private String tag;
	public void setTag(String tag) {
		this.tag = tag;
	}

	public void setIdtags(Integer idtags) {
		this.idtags = idtags;
	}
	public String getTag() {
		return tag;
	}
	

}
