package com.sdfunction.db.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sdfunction.db.demo.models.Functions;
import com.sdfunction.db.demo.models.ReturnTypes;
import com.sdfunction.db.demo.models.Tags;
import com.sdfunction.db.demo.repository.ReturnTypeRepository;
import com.sdfunction.db.demo.repository.TagsRepository;


@CrossOrigin(origins = "http://localhost:4200", maxAge = 3600)
@RestController
@RequestMapping(value="/rest/functions/return")
public class ReturnTypeController {
	@Autowired
	ReturnTypeRepository returnRepo ;
	
	@GetMapping(value="/all")
	public List<ReturnTypes> getAll() {
		return returnRepo.findAll();
	}
	@PostMapping(value="/load")
	public void create(@RequestBody final ReturnTypes ret){
		returnRepo.save(ret);
		
	}
	@DeleteMapping("/{id}")
	public void getFunctionById(@PathVariable(value="id") Integer id) {
		returnRepo.deleteById(id);
		
	}
	
	
}
