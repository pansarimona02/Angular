package com.sdfunction.db.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sdfunction.db.demo.models.Parameters;

public interface ParameterRepository extends JpaRepository<Parameters, Integer> {
	//public List<Parameters> findByFunction(Integer funId);

}
